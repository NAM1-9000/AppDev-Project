// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';

// class ListTileWidget extends StatelessWidget {
//   final String title;
//   final String category;
//   final String amount;
//   final DateTime dateTime;

//   const ListTileWidget({
//     super.key,
//     required this.title,
//     required this.category,
//     required this.amount,
//     required this.dateTime,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return ListTile(
//       title: Text(title),
//       subtitle: Text(category),
//       trailing: Column(
//         crossAxisAlignment: CrossAxisAlignment.end,
//         children: [
//           Text(amount),
//           Text(DateFormat.yMMMd().format(dateTime)),
//         ],
//       ),
//     );
//   }
// }
