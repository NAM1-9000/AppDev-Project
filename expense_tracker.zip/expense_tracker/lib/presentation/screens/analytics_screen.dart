// import 'package:expense_tracker/presentation/widgets/appbar.dart';
// import 'package:expense_tracker/presentation/widgets/naviagtion_menu.dart';
// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';

// class AnalyticsScreen extends StatefulWidget {
//   const AnalyticsScreen({super.key});

//   @override
//   State<AnalyticsScreen> createState() => _AnalyticsScreenState();
// }

// class _AnalyticsScreenState extends State<AnalyticsScreen> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: buildAppBar(
//           DateFormat('EEEE, d MMMM').format(DateTime.now()), '42000', '69420'),
//       bottomNavigationBar: const BottomNavigation(),
//     );
//   }
// }
