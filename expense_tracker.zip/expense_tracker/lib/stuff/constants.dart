class Constants {
  static const logoPath = 'assets/logo.png';
  static const googleLogoPath = 'assets/google.png';
}
