class PieChartData {
  final String category;
  final double amount;

  PieChartData({required this.category, required this.amount});
}
